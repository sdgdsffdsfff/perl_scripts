from mock_demo import E

def do_create_stuff():
    obj = E(val=7)
    print obj.method1()
